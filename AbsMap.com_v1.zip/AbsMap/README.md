# AbsMap.com

Primeira versão funcional do AbsMap.com.

## Como usar
1. Abra `index.html` em um navegador com internet.
2. O mapa usa Leaflet + OpenStreetMap.
3. Os marcadores atuais são DEMONSTRAÇÃO e não representam localizações oficiais de GTA 6.
4. Edite o array `places` no final do HTML para adicionar dados.

## Próximas etapas
- migrar os dados para Supabase/PostgreSQL;
- criar painel administrativo;
- autenticação;
- upload de imagens;
- favoritos e progresso;
- importar/exportar JSON/CSV;
- adicionar uma imagem/base cartográfica licenciada de Leonida quando disponível.
